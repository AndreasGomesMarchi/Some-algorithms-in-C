#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
	
	float num1, num2, result;
	
	result = num1 / num2;
	
	printf ("Escreva um numero: ");
	scanf ("%f", &num1);
	
	printf ("Escreva outro numero: ");
	scanf ("%f", &num2);
	
	result = num1 + num2;
	printf ("A soma entre eles e: %.0f \n", result);
	
	result = num1 - num2;
	printf ("A subtracao entre eles e: %.0f \n", result);
	
	result = num1 * num2;
	printf ("A multiplicacao entre eles e: %.0f \n", result);
	
	result = num1 / num2;
	printf ("A divisao entre eles e: %.0f \n", result);
	
	return 0;
	
	
	
	
	
	
	
	
	
	

	
	
	//float a, b, c, delta;
	
	//printf ("Digite o primeiro numero: ");
//	scanf ("%f", &a);
	
//	printf ("Digite o segundo numero: ");
	//scanf ("%f", &b);
	
//	printf ("Digite o terceiro numero: ");
//	scanf ("%f", &c);
	
//	delta = (b*b) - 4*a*c;
	
	//printf ("O valor do delta e  %f", delta);
	
//	return 0;
	
}
	
	
	
	
	
	
	
