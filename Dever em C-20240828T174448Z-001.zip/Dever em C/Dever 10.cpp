#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main() {
	
	float v1, v2, v3, p1, p2, p3, mediaP;

	printf ("Qual e o valor do tijolo na primeira loja? "); //o valor do tijolo equivale ao valores
	scanf ("%f", &v1);

    printf ("Qual e o numero de tijolos comprados? "); //o número de tijolos comprados equivale ao peso
	scanf ("%f", &p1);

    printf ("Qual e o valor do tijolo na segunda loja? "); //o valor do tijolo equivale ao valores
	scanf ("%f", &v2);

    printf ("Qual e o numero de tijolos comprados? "); //o número de tijolos comprados equivale ao peso
	scanf ("%f", &p2);

    printf ("Qual e o valor do tijolo na terceira loja? "); //o valor do tijolo equivale ao valores
	scanf ("%f", &v3);

    printf ("Qual e o numero de tijolos comprados? "); //o número de tijolos comprados equivale ao peso
	scanf ("%f", &p3);

	mediaP = ((p1*v1) + (p2*v2) + (p3*v3)) / (p1+p2+p3);

	printf ("A media ponderada dos valores da tres lojas e %.2fR$.", mediaP);

    return 0;






















//#define pi 3.1415  <-- isso fica antes do int main()
	//float circunferencia;
	//int dia; 
	
	//printf ("Calculador de circunferencia de um circulo! \n Qual e o valor do diametro? ");
	//scanf ("%i", &dia);

	//circunferencia = dia * pi;

	//printf ("O valor da cirfunferencia e: %.4f", circunferencia);
	
	//return 0;
	
	
	
	
//	float bas, exp, res;
	
	//printf ("Escolha um numero: ");
//	scanf ("%f", &bas);
	
	//printf ("Escolha o expoente desse numero: ");
	//scanf ("%f", &exp);
	
	//res = pow(bas, exp);
	
//	printf ("O numero escolhido foi %.0f e o seu quadrado %.0f\n", bas, res);
	
	//return 0; 
	
	
	
	
	
    //char palavra1[50], palavra2[50]; 
    
    //printf ("Escreva uma palavra aqui: ");
    //scanf ("%s", palavra1);
    
    //strcpy (palavra2, palavra1);
    
    //printf ("A sua palavra e muito bonita, por isso vou repiti-la aqui %s", palavra2);
    
    //return 0; 
	
	

	
	
	/*float bas, exp, res;
	
	printf ("Escolha a base: ");
	scanf ("%f", &bas);
	
	printf ("Escolha o expoente: ");
	scanf ("%f", &exp);
	
	res = pow(bas, exp);
	
	printf ("%.0f elevado a %.0f e %.0f\n", bas, exp, res);
	
	return 0; */
	
	

	
	
	/* float num1, num2, result;
	
	result = num1 / num2;
	
	printf ("Escreva um numero: ");
	scanf ("%f", &num1);
	
	printf ("Escreva outro numero: ");
	scanf ("%f", &num2);
	
	result = num1 + num2;
	printf ("A soma entre eles e: %.0f \n", result);
	
	result = num1 - num2;
	printf ("A subtracao entre eles e: %.0f \n", result);
	
	result = num1 * num2;
	printf ("A multiplicacao entre eles e: %.0f \n", result);
	
	result = num1 / num2;
	printf ("A divisao entre eles e: %.0f \n", result);
	
	return 0; */
	
	
	
	
	
	
	
	
	
	

	
	
	//float a, b, c, delta;
	
	//printf ("Digite o primeiro numero: ");
//	scanf ("%f", &a);
	
//	printf ("Digite o segundo numero: ");
	//scanf ("%f", &b);
	
//	printf ("Digite o terceiro numero: ");
//	scanf ("%f", &c);
	
//	delta = (b*b) - 4*a*c;
	
	//printf ("O valor do delta e  %f", delta);
	
//	return 0;
	
}
	
	
	
	
	
	
	
