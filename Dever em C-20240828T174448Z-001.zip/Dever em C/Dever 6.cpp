#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

int main() {
	
	float bas, exp, res;
	
	printf ("Escolha um numero: ");
	scanf ("%f", &bas);
	
	printf ("Escolha o expoente desse numero: ");
	scanf ("%f", &exp);
	
	res = pow(bas, exp);
	
	printf ("O numero escolhido foi %.0f e o seu quadrado %.0f\n", bas, res);
	
	return 0; 
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
    //char palavra1[50], palavra2[50]; 
    
    //printf ("Escreva uma palavra aqui: ");
    //scanf ("%s", palavra1);
    
    //strcpy (palavra2, palavra1);
    
    //printf ("A sua palavra e muito bonita, por isso vou repiti-la aqui %s", palavra2);
    
    //return 0; 
	
	

	
	
	/*float bas, exp, res;
	
	printf ("Escolha a base: ");
	scanf ("%f", &bas);
	
	printf ("Escolha o expoente: ");
	scanf ("%f", &exp);
	
	res = pow(bas, exp);
	
	printf ("%.0f elevado a %.0f e %.0f\n", bas, exp, res);
	
	return 0; */
	
	

	
	
	/* float num1, num2, result;
	
	result = num1 / num2;
	
	printf ("Escreva um numero: ");
	scanf ("%f", &num1);
	
	printf ("Escreva outro numero: ");
	scanf ("%f", &num2);
	
	result = num1 + num2;
	printf ("A soma entre eles e: %.0f \n", result);
	
	result = num1 - num2;
	printf ("A subtracao entre eles e: %.0f \n", result);
	
	result = num1 * num2;
	printf ("A multiplicacao entre eles e: %.0f \n", result);
	
	result = num1 / num2;
	printf ("A divisao entre eles e: %.0f \n", result);
	
	return 0; */
	
	
	
	
	
	
	
	
	
	

	
	
	//float a, b, c, delta;
	
	//printf ("Digite o primeiro numero: ");
//	scanf ("%f", &a);
	
//	printf ("Digite o segundo numero: ");
	//scanf ("%f", &b);
	
//	printf ("Digite o terceiro numero: ");
//	scanf ("%f", &c);
	
//	delta = (b*b) - 4*a*c;
	
	//printf ("O valor do delta e  %f", delta);
	
//	return 0;
	
}
	
	
	
	
	
	
	
