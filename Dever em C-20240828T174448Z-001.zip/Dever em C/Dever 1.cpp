#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main() {
	
	float a, b, c, delta;
	
	printf ("Digite o primeiro numero: ");
	scanf ("%f", &a);
	
	printf ("Digite o segundo numero: ");
	scanf ("%f", &b);
	
	printf ("Digite o terceiro numero: ");
	scanf ("%f", &c);
	
	delta = (b*b) - 4*a*c;
	
	printf ("O valor do delta e  %f", delta);
	
	return 0;
	
}
	
	
	
	
	
	
	
